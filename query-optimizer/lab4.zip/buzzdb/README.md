
  

#  CS 4423/6423 Lab 4: Query Optimization


