
#include <cassert>
#include <iostream>
#include <string>

#include "buffer/buffer_manager.h"
#include "common/macros.h"
#include "storage/file.h"
#include <chrono>
#include <ctime> 

uint64_t wake_timeout_ = 100;
uint64_t timeout_ = 2;

namespace buzzdb {

char* BufferFrame::get_data() { return data.data(); }

BufferFrame::BufferFrame()
    : page_id(INVALID_PAGE_ID),
      frame_id(INVALID_FRAME_ID),
      dirty(false),
      exclusive(false) {}

BufferFrame::BufferFrame(const BufferFrame& other)
    : page_id(other.page_id),
      frame_id(other.frame_id),
      data(other.data),
      dirty(other.dirty),
      exclusive(other.exclusive) {}

BufferFrame& BufferFrame::operator=(BufferFrame other) {
  std::swap(this->page_id, other.page_id);
  std::swap(this->frame_id, other.frame_id);
  std::swap(this->data, other.data);
  std::swap(this->dirty, other.dirty);
  std::swap(this->exclusive, other.exclusive);
  return *this;
}

BufferManager::BufferManager(size_t page_size, size_t page_count) {
  capacity_ = page_count;
  page_size_ = page_size;

  pool_.resize(capacity_);
  for (size_t frame_id = 0; frame_id < capacity_; frame_id++) {
    pool_[frame_id].reset(new BufferFrame());
    pool_[frame_id]->data.resize(page_size_);
    pool_[frame_id]->frame_id = frame_id;
  }
}

BufferManager::~BufferManager() {
}


BufferFrame& BufferManager::fix_page(UNUSED_ATTRIBUTE uint64_t txn_id, UNUSED_ATTRIBUTE uint64_t page_id, UNUSED_ATTRIBUTE bool exclusive) {
    return *pool_[0];
}

void BufferManager::unfix_page(UNUSED_ATTRIBUTE uint64_t txn_id, UNUSED_ATTRIBUTE BufferFrame& page, UNUSED_ATTRIBUTE bool is_dirty) {
}

void  BufferManager::flush_all_pages(){

	for (size_t frame_id = 0; frame_id < capacity_; frame_id++) {
		if (pool_[frame_id]->dirty == true) {
			write_frame(frame_id);
		}
	}

}


void  BufferManager::discard_all_pages(){

	for (size_t frame_id = 0; frame_id < capacity_; frame_id++) {
		pool_[frame_id].reset(new BufferFrame());
		pool_[frame_id]->page_id = INVALID_PAGE_ID;
		pool_[frame_id]->dirty = false;
		pool_[frame_id]->data.resize(page_size_);
	}

}

void BufferManager::discard_pages(UNUSED_ATTRIBUTE uint64_t txn_id){
  // Discard all pages acquired by the transaction 
  
}

void BufferManager::flush_pages(UNUSED_ATTRIBUTE uint64_t txn_id){
    // Flush all dirty pages acquired by the transaction to disk
}

void BufferManager::transaction_complete(UNUSED_ATTRIBUTE uint64_t txn_id){
    // Free all the locks acquired by the transaction
}

void BufferManager::transaction_abort(UNUSED_ATTRIBUTE uint64_t txn_id){
    // Free all the locks acquired by the transaction
}


void BufferManager::read_frame(uint64_t frame_id) {
  std::lock_guard<std::mutex> file_guard(file_use_mutex_);

  auto segment_id = get_segment_id(pool_[frame_id]->page_id);
  auto file_handle =
      File::open_file(std::to_string(segment_id).c_str(), File::WRITE);
  size_t start = get_segment_page_id(pool_[frame_id]->page_id) * page_size_;
  file_handle->read_block(start, page_size_, pool_[frame_id]->data.data());
}

void BufferManager::write_frame(uint64_t frame_id) {
  std::lock_guard<std::mutex> file_guard(file_use_mutex_);

  auto segment_id = get_segment_id(pool_[frame_id]->page_id);
  auto file_handle =
      File::open_file(std::to_string(segment_id).c_str(), File::WRITE);
  size_t start = get_segment_page_id(pool_[frame_id]->page_id) * page_size_;
  file_handle->write_block(pool_[frame_id]->data.data(), start, page_size_);
}


}  // namespace buzzdb
