# BuzzDB
Visit [Lab1](https://buzzdb-docs.readthedocs.io/part2/lab1.html) for detailed description of the lab.